import os

def rename_and_modify(directory):
    # 递归处理目录及其子目录下的所有 .m4s 文件
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename.endswith('.m4s'):
                file_path = os.path.join(root, filename)
                rename_m4s_file(file_path)
                remove_leading_zeros(file_path)

def rename_m4s_file(file_path):
    # 获取文件所在目录和文件名
    directory = os.path.dirname(file_path)
    base_name = os.path.basename(file_path)
    
    # 重命名文件为顺序编号
    index = 1
    new_name = f"{index}.m4s"
    new_path = os.path.join(directory, new_name)
    
    # 如果目标文件已存在，则添加序号直到找到一个不存在的文件名
    while os.path.exists(new_path):
        index += 1
        new_name = f"{index}.m4s"
        new_path = os.path.join(directory, new_name)
    
    os.rename(file_path, new_path)

def remove_leading_zeros(file_path):
    # 读取文件内容并删除开头的前9个零字符
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
        
        modified_content = content[9:]  # 删除前9个字节
        
        # 将修改后的内容写回文件
        with open(file_path, 'wb') as f:
            f.write(modified_content)
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")

if __name__ == "__main__":
    current_directory = os.getcwd()  # 获取当前工作目录
    rename_and_modify(current_directory)
