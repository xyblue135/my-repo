import os
import subprocess
from datetime import datetime

def rename_and_modify(directory):
    # 递归处理目录及其子目录下的所有 .m4s 文件
    for root, dirs, files in os.walk(directory):
        for dirname in dirs:
            subdir_path = os.path.join(root, dirname)
            merge_m4s_to_mp4(subdir_path)  # 对每个子目录执行合并操作

def rename_m4s_file(file_path):
    # 获取文件的创建时间
    creation_time = os.path.getctime(file_path)
    timestamp = datetime.fromtimestamp(creation_time).strftime('%Y%m%d_%H%M%S')
    
    # 获取文件所在目录和文件名
    directory = os.path.dirname(file_path)
    base_name = os.path.basename(file_path)
    
    # 构建新的文件名，包括时间戳
    new_name = f"{timestamp}_{base_name}"
    new_path = os.path.join(directory, new_name)
    
    # 如果目标文件已存在，则添加序号直到找到一个不存在的文件名
    index = 1
    while os.path.exists(new_path):
        index += 1
        new_name = f"{timestamp}_{index}_{base_name}"
        new_path = os.path.join(directory, new_name)
    
    os.rename(file_path, new_path)

def remove_leading_zeros(file_path):
    # 读取文件内容并删除开头的前9个零字符
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
        
        modified_content = content[9:]  # 删除前9个字节
        
        # 将修改后的内容写回文件
        with open(file_path, 'wb') as f:
            f.write(modified_content)
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")

def merge_m4s_to_mp4(directory):
    # 收集所有 .m4s 文件路径
    m4s_files = []
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename.endswith('.m4s'):
                file_path = os.path.join(root, filename)
                m4s_files.append(file_path)
    
    if not m4s_files:
        print(f"No .m4s files found in {directory}")
        return
    
    # 创建输出目录 output 相对于当前工作目录
    output_directory = os.path.join(directory, 'output')
    os.makedirs(output_directory, exist_ok=True)
    
    # 获取父目录名称作为输出文件名
    parent_directory_name = os.path.basename(directory)
    output_file = os.path.join(output_directory, f"{parent_directory_name}.mp4")
    
    # 构建 ffmpeg 命令
    input_files = " ".join([f"-i \"{f}\"" for f in m4s_files])
    ffmpeg_cmd = f"ffmpeg {input_files} -codec copy \"{output_file}\""
    
    # 执行 ffmpeg 命令
    try:
        subprocess.run(ffmpeg_cmd, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error executing ffmpeg command: {e}")

if __name__ == "__main__":
    current_directory = os.getcwd()  # 获取当前工作目录
    rename_and_modify(current_directory)
