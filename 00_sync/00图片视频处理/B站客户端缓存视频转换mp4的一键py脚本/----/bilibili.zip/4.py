import os
import shutil

def copy_output_folders(directory):
    # 遍历当前目录及其子目录
    for root, dirs, files in os.walk(directory):
        for dirname in dirs:
            subdir_path = os.path.join(root, dirname)
            output_dir = os.path.join(subdir_path, 'output')
            if os.path.exists(output_dir):
                # 复制 output 文件夹中的所有文件到当前目录下的所有视频文件夹中
                copy_files_to_all_videos(output_dir)

def copy_files_to_all_videos(source_dir):
    # 创建当前目录下的所有视频文件夹，如果不存在则创建
    target_dir = os.path.join(os.getcwd(), '所有视频')
    os.makedirs(target_dir, exist_ok=True)

    # 复制 source_dir 中的所有文件到 target_dir 中
    for item in os.listdir(source_dir):
        item_path = os.path.join(source_dir, item)
        if os.path.isfile(item_path):
            shutil.copy(item_path, target_dir)
        elif os.path.isdir(item_path):
            # 如果是文件夹，递归复制其内容
            shutil.copytree(item_path, os.path.join(target_dir, item))

if __name__ == "__main__":
    current_directory = os.getcwd()  # 获取当前工作目录
    copy_output_folders(current_directory)
