import os

def process_m4s_files(directory):
    # 遍历当前目录及其子目录下的所有文件
    for root, _, files in os.walk(directory):
        for filename in files:
            if filename.endswith(('1.m4s', '2.m4s')):
                file_path = os.path.join(root, filename)
                try:
                    # 读取文件内容
                    with open(file_path, 'r+b') as f:
                        content = f.read()
                        # 删除前9位内容（如果文件内容长度不足9位，直接清空文件）
                        f.seek(0)
                        f.truncate()
                        f.write(content[9:])
                    print(f"成功删除编码前9位：{file_path}")
                except Exception as e:
                    print(f"处理文件时出错：{file_path}")
                    print(e)

if __name__ == "__main__":
    current_directory = os.getcwd()  # 获取当前工作目录
    process_m4s_files(current_directory)
